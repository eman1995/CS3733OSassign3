#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int PT[12] = {2, 4, 1, 7, 3, 5, 6, 0, 0, 0, 0, 0};

unsigned long translate(unsigned long buffer)
{
    unsigned long p_num = buffer >> 7;
    unsigned long offset = buffer & 0x07F;
    unsigned long f_num = PT[p_num];
    unsigned long phyAddr = (f_num << 7) + offset;
    return phyAddr;
}

void printBytes(char *buff)
{
    int i;
    for(i = 0; i < sizeof(buff); i++)
    {
//        printf("%lx ", buff[i]);

        if(buff[i+1] == '\0')
        { 
            printf("\n");
            return;
        }
    }
}

int main(int argc, char *argv[])
{
    char infile[128];
    char outfile[128];
    unsigned long buffer, PA;
    //different way of reading the argv
    memset(infile, '\0', sizeof(infile));
    memset(infile, '\0', sizeof(outfile));
//    memset(buffer, '\0', sizeof(buffer));

    strcpy(infile, argv[1]);
    strcpy(outfile, argv[2]);
    //open files in binary
    FILE *fptr1 = fopen(infile, "rb");
    FILE *fptr2 = fopen(outfile, "wb+");//if files dosn't exist 

    while(fread(&buffer, sizeof(buffer), 1L, fptr1) == 1)
    {
        //printf("%lx\n", buffer);
        //printf("%i\n", buffer>>7);
        PA = translate(buffer);
        //printBytes(buffer); 
        fwrite(&PA, sizeof(PA), 1L, fptr2);
    }
    return 0;
}

